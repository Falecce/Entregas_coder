# Este script está pensado para correr en Spark y hacer el proceso de ETL de la tabla users

import requests
import urllib.parse
from datetime import datetime, timedelta
from os import environ as env

from pyspark.sql.functions import concat, col, lit, when, expr, to_date, monotonically_increasing_id

from commons import ETL_Spark

class ETL_Fabio(ETL_Spark):
    def __init__(self, job_name=None):
        super().__init__(job_name)
        self.process_date = datetime.now().strftime("%Y-%m-%d")

    def run(self):
        process_date = "2023-07-09"  # datetime.now().strftime("%Y-%m-%d")
        self.execute(process_date)

    def extract(self):
        """
        Extrae datos de la API
        """
        print(">>> [E] Extrayendo datos de la API...")

        def get_api_call(ids, **kwargs):
            API_BASE_URL = "https://apis.datos.gob.ar/series/api/"
            kwargs["ids"] = ",".join(ids)
            
            return "{}{}?{}".format(API_BASE_URL, "series", urllib.parse.urlencode(kwargs))
        
        api_call = get_api_call(["Automotriz_produccion_s2nqOo,Automotriz_expos_ItCfsr"])
        result = requests.get(api_call).json()
        df = self.spark.createDataFrame(result['data'], ["date_from", "vehiculos_producidos", "vehiculos_exportados"])
        df.printSchema()
        df.show()

        return df

    def transform(self, df_original):
        """
        Transforma los datos
        """
        print(">>> [T] Transformando datos...")
        #Eliminamos duplicados

        df = df_original.withColumn(
            'Diferencia', df_original.vehiculos_producidos - df_original.vehiculos_exportados
        )

        df = df.withColumn(
            'Porcentaje_exportacion', 100 * df_original.vehiculos_exportados / df_original.vehiculos_producidos
        )

        df = df.orderBy(col("date_from").asc())

        df = df.withColumn('frequency', lit('Mensual'))

        df.printSchema()
        df.show()

        return df

    def load(self, df_final):
        """
        Carga los datos transformados en Redshift
        """
        print(">>> [L] Cargando datos en Redshift...")

        # add process_date column
        df_final = df_final.withColumn("process_date", lit(self.process_date))

        df_final.write \
            .format("jdbc") \
            .option("url", env['REDSHIFT_URL']) \
            .option("dbtable", f"{env['REDSHIFT_SCHEMA']}.vehiculos_producidos_vs_exportados2") \
            .option("user", env['REDSHIFT_USER']) \
            .option("password", env['REDSHIFT_PASSWORD']) \
            .option("driver", "org.postgresql.Driver") \
            .mode("append") \
            .save()
        
        print(">>> [L] Datos cargados exitosamente")


if __name__ == "__main__":
    print("Corriendo script")
    etl = ETL_Fabio()
    etl.run()
